package com.example.a_i_tortue

data class Country(var code: String) {


}