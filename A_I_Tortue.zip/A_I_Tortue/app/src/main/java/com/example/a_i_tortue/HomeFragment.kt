package com.example.a_i_tortue

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

/**
 * A simple [Fragment] subclass.
 */
class HomeFragment : Fragment() {

    lateinit var mAuth:FirebaseAuth
    lateinit var currentUser:FirebaseUser
    lateinit var crdViewModel:CardView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view=inflater.inflate(R.layout.fragment_home, container, false)

        mAuth=FirebaseAuth.getInstance()
        val email=mAuth.currentUser?.email
        Toast.makeText(activity,email,Toast.LENGTH_LONG).show()

        crdViewModel=view.findViewById(R.id.cardViewModuleTests)

        crdViewModel.setOnClickListener {
            val intent=Intent(activity,SetupActivity::class.java)
            startActivity(intent)
        }

        return view
    }

}
