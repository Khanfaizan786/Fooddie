package com.example.a_i_tortue

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.squareup.picasso.Picasso
import de.hdodenhof.circleimageview.CircleImageView

/**
 * A simple [Fragment] subclass.
 */
class ProfileFragment : Fragment() {

    private lateinit var mAuth:FirebaseAuth
    private lateinit var usersRef:DatabaseReference
    private lateinit var currentUserId:String

    lateinit var imgPersonProfilePic:CircleImageView
    lateinit var txtPersonProfileName:TextView
    lateinit var txtPersonProfileCountry:TextView
    lateinit var txtPersonProfileEmail:TextView
    lateinit var txtPersonProfileContact:TextView
    lateinit var txtPersonProfileDob:TextView
    lateinit var txtPersonProfileGender:TextView
    lateinit var btnEditPersonProfile:Button
    lateinit var myProfileImage:String

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view= inflater.inflate(R.layout.fragment_profile, container, false)

        mAuth=FirebaseAuth.getInstance()
        currentUserId= mAuth.currentUser?.uid.toString()
        usersRef=FirebaseDatabase.getInstance().reference.child("Users").child(currentUserId)

        imgPersonProfilePic =view.findViewById(R.id.imgPersonProfilePic)
        txtPersonProfileName=view.findViewById(R.id.txtPersonProfileName)
        txtPersonProfileCountry=view.findViewById(R.id.txtPersonProfileCountry)
        txtPersonProfileEmail=view.findViewById(R.id.txtPersonProfileEmail)
        txtPersonProfileContact=view.findViewById(R.id.txtPersonProfileContact)
        txtPersonProfileDob=view.findViewById(R.id.txtPersonProfileDob)
        txtPersonProfileGender=view.findViewById(R.id.txtPersonProfileGennder)
        btnEditPersonProfile=view.findViewById(R.id.btnEditPersonProfile)

        val postListener=object:ValueEventListener{
            override fun onCancelled(error: DatabaseError) {
                val message=error.message
                Toast.makeText(activity,"Error occured: $message" ,Toast.LENGTH_LONG).show()
            }

            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    if (snapshot.hasChild("profileImage")) {
                        myProfileImage=snapshot.child("profileImage").value.toString()
                        Picasso.with(activity).load(myProfileImage).placeholder(R.drawable.profile).into(imgPersonProfilePic)
                    }
                    val myFullName:String = snapshot.child("name").value.toString()
                    var myCountry: String = snapshot.child("country").value.toString()
                    var myEmail: String = snapshot.child("email").value.toString()
                    var myContact: String = snapshot.child("phone").value.toString()
                    var myDOB: String = snapshot.child("dob").value.toString()
                    var myGender: String = snapshot.child("gender").value.toString()

                    myCountry="Country : $myCountry"
                    myEmail="Email : $myEmail"
                    myContact="Contact No. : $myContact"
                    myDOB="DOB : $myDOB"
                    myGender="Gender : $myGender"

                    txtPersonProfileName.text=myFullName
                    if (myCountry == "Select") {
                        val country="No Country"
                        txtPersonProfileCountry.text=country
                    } else {
                        txtPersonProfileCountry.text=myCountry
                    }
                    txtPersonProfileEmail.text=myEmail
                    txtPersonProfileContact.text=myContact
                    txtPersonProfileDob.text=myDOB
                    if (myGender=="Select") {
                        val gender="No Gender"
                        txtPersonProfileGender.text=gender
                    } else {
                        txtPersonProfileGender.text=myGender
                    }
                }
            }
        }

        usersRef.addValueEventListener(postListener)

        btnEditPersonProfile.setOnClickListener {
            val intent=Intent(activity,SetupActivity::class.java)
            activity?.startActivity(intent)

        }

        return view
    }
}
